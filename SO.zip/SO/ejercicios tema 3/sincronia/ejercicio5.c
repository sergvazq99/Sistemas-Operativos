#include <pthread.h>

#include <stdio.h>

#include <unistd.h>

pthread_mutex_t m;

int turno = 0; // 0 -> A, 1 -> B



void *A(void *arg) {
    pthread_mutex_lock(&m);
    if(turno==0){
        printf("Turno de A\n");
        turno=1;
    }
    else{
        printf("Turno de B\n");
        turno=0;
    }
    pthread_mutex_unlock(&m);
    return NULL;

}



void *B(void *arg) {
    pthread_mutex_lock(&m);
    if(turno==1){
        printf("Turno de B\n");
        turno=0;
    }
    else{
        printf("Turno de A\n");
        turno=1;
    }
    pthread_mutex_unlock(&m);
    return NULL;

}

int main(void) {
   pthread_t a[10], b[10];

    pthread_mutex_init(&m,NULL);

    for(int i=0;i<10;i++){
        pthread_create(&a[i],NULL,A,NULL);
    }
    for(int i=0;i<10;i++){
        pthread_create(&b[i],NULL,B,NULL);
    }

    for(int i=0;i<10;i++){
        pthread_join(a[i],NULL);
    }
    for(int i=0;i<10;i++){
        pthread_join(b[i],NULL);
    }

    pthread_mutex_destroy(&m);
    return 0;
}