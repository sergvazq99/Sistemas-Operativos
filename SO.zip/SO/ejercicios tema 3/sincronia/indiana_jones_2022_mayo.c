#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

#define N 10

int indianos=0;
int molarams=0;

pthread_mutex_t mutex;
pthread_cond_t indiano_cruza;
pthread_cond_t molaram_cruza;

void* indiano(void*arg) {
    int id=*(int*)arg;
    pthread_mutex_lock(&mutex);

    while(indianos+molarams>=4||molarams>0){
        pthread_cond_wait(&indiano_cruza,&mutex);
    }

    indianos++;
    printf("Indiano entra en el puente: %d \n", id);

    pthread_mutex_unlock(&mutex);
    sleep(2);
    pthread_mutex_lock(&mutex);

    indianos--;
    printf("Indiano sale del puente: %d \n", id);

    pthread_cond_broadcast(&indiano_cruza);
    pthread_cond_broadcast(&molaram_cruza);

    pthread_mutex_unlock(&mutex);
    return NULL;
}

void* molaRam(void*arg) {
    int id=*(int*)arg;
    pthread_mutex_lock(&mutex);

    while(indianos==0||molarams>0||indianos + molarams >= 4){
        pthread_cond_wait(&molaram_cruza,&mutex);
    }

    molarams++;

    printf("MolaRam entra en el puente: %d\n", id);

    pthread_mutex_unlock(&mutex);
    sleep(2);
    pthread_mutex_lock(&mutex);

    molarams--;
    printf("MolaRam sale del puente: %d\n", id);

    pthread_cond_broadcast(&indiano_cruza);
    pthread_cond_broadcast(&molaram_cruza);
    
    pthread_mutex_unlock(&mutex);
    return NULL;
}

int main(){
    pthread_t indianos[N],molarams[N];
    int idsInd[N],idsMrms[N];

    pthread_mutex_init(&mutex,NULL);
    pthread_cond_init(&indiano_cruza,NULL);
    pthread_cond_init(&molaram_cruza,NULL);

    for(int i=0;i<N;i++){
        idsInd[i]=i;
        pthread_create(&indianos[i],NULL,indiano,&idsInd[i]);
        idsMrms[i]=i;
        pthread_create(&molarams[i],NULL,molaRam,&idsMrms[i]);
    }
    for(int i=0;i<N;i++){
        pthread_join(indianos[i],NULL);
        pthread_join(molarams[i],NULL);
    }

    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&indiano_cruza);
    pthread_cond_destroy(&molaram_cruza);

    return 0;
}

