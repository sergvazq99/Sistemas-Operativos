#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

#define N 3

int buffer[N];

int in = 0, out = 0, ocupados = 0;

pthread_mutex_t m;

pthread_cond_t hay_dato, hay_hueco;

void *productor(void *arg) {
    int id=*(int*)arg;
    for(int i=0;i<10;i++){
        pthread_mutex_lock(&m);
        
        while(ocupados==N){
            pthread_cond_wait(&hay_hueco,&m);
        }
        ocupados++;
        buffer[in]=i+1;
        printf("Produciendo dato: %d, Hilo: %d\n",buffer[in],id);
        in=(in+1)%N;
        
        pthread_cond_signal(&hay_dato);
        pthread_mutex_unlock(&m);
        sleep(1);
    }
    return NULL;
}



void *consumidor(void *arg) {
    int id=*(int*)arg;
    for(int i=0;i<10;i++){
        pthread_mutex_lock(&m);
        
        while(ocupados==0){
            pthread_cond_wait(&hay_dato,&m);
        }
        ocupados--;
        
        printf("Consumiendo dato: %d, Hilo: %d \n",buffer[out],id);
        out=(out+1)%N;

        pthread_cond_signal(&hay_hueco);
        pthread_mutex_unlock(&m);
        sleep(1);
    }
    return NULL;
}


int main(void){
    pthread_t _productor[10],_consumidor[10];
    int ids[10];
    pthread_mutex_init(&m,NULL);
    pthread_cond_init(&hay_dato,NULL);
    pthread_cond_init(&hay_hueco,NULL);

    
    for(int i=0;i<10;i++){
        ids[i]=i;
        pthread_create(&_productor[i],NULL,productor,&ids[i]);
        pthread_create(&_consumidor[i],NULL,consumidor,&ids[i]);
    }
    
    for(int i=0;i<10;i++){
        pthread_join(_productor[i],NULL);
        pthread_join(_consumidor[i],NULL);
    }

    pthread_mutex_destroy(&m);
    pthread_cond_destroy(&hay_dato);
    pthread_cond_destroy(&hay_hueco);

    return 0;
}