#include <pthread.h>

#include <stdio.h>

#include <unistd.h>



pthread_mutex_t impresora;



void *trabajador(void *arg) {
    int id = *(int *)arg;

    pthread_mutex_lock(&impresora);

    printf("Hilo %d entra en la impresora\n", id);

    sleep(1);

    printf("Hilo %d sale de la impresora\n", id);

    pthread_mutex_unlock(&impresora);
    return NULL;
}

int main(void) {
    pthread_t hilos[10];
    int ids[10];

    pthread_mutex_init(&impresora,NULL);

    for(int i=0;i<10;i++){
        ids[i]=i;
        pthread_create(&hilos[i],NULL,trabajador,&ids[i]);    
    }

    for(int i=0;i<10;i++){
        pthread_join(hilos[i],NULL);    
    }
    
    pthread_mutex_destroy(&impresora);
    return 0;
}