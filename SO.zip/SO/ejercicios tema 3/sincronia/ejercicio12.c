#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

#define N 3

int buffer[N];

int in = 0, out = 0, ocupados = 0;

pthread_mutex_t m;

pthread_cond_t hay_dato, hay_hueco;

void *productor(void *arg) {
    for(int i=0;i<10;i++){
        pthread_mutex_lock(&m);
        
        while(ocupados==N){
            pthread_cond_wait(&hay_hueco,&m);
        }
        ocupados++;
        buffer[in]=i+1;
        printf("Produciendo dato: %d\n",buffer[in]);
        in=(in+1)%N;
        
        pthread_cond_signal(&hay_dato);
        pthread_mutex_unlock(&m);
        sleep(1);
    }
    return NULL;
}



void *consumidor(void *arg) {
    for(int i=0;i<10;i++){
        pthread_mutex_lock(&m);
        
        while(ocupados==0){
            pthread_cond_wait(&hay_dato,&m);
        }
        ocupados--;
        
        printf("Consumiendo dato: %d\n",buffer[out]);
        out=(out+1)%N;

        pthread_cond_signal(&hay_hueco);
        pthread_mutex_unlock(&m);
        sleep(1);
    }
    return NULL;
}


int main(void){
    pthread_t _productor,_consumidor;

    pthread_mutex_init(&m,NULL);
    pthread_cond_init(&hay_dato,NULL);
    pthread_cond_init(&hay_hueco,NULL);

    
        
    pthread_create(&_productor,NULL,productor,NULL);
    pthread_create(&_consumidor,NULL,consumidor,NULL);
    

    
    pthread_join(_productor,NULL);
    pthread_join(_consumidor,NULL);
    

    pthread_mutex_destroy(&m);
    pthread_cond_destroy(&hay_dato);
    pthread_cond_destroy(&hay_hueco);

    return 0;
}