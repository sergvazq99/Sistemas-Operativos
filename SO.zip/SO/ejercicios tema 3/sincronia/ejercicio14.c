#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

int active = 0;

const int capacity = 3;

pthread_mutex_t m;

pthread_cond_t hay_hueco;



void *enter(void*arg) {
    int id=*(int*)arg;

    pthread_mutex_lock(&m);
    while(active==capacity){
        pthread_cond_wait(&hay_hueco,&m);
    }
    active++;
    printf("Entrando a la piscina con gante: %d, Hilo: %d\n",active,id);

    pthread_mutex_unlock(&m);
    sleep(1);
    return NULL;
}



void *leave(void*arg) {
    int id=*(int*)arg;

    pthread_mutex_lock(&m);
    while(active == 0){
        pthread_cond_wait(&hay_hueco, &m);
    }
    active--;

    printf("Dejando la piscina con gante: %d, Hilo: %d\n",active,id);
    pthread_cond_signal(&hay_hueco);
    pthread_mutex_unlock(&m);

    sleep(1);
    return NULL;
}

int main(void){
    pthread_t _entrar[10],_irse[10];
    int idsE[10],idsS[10];
    pthread_mutex_init(&m,NULL);
    pthread_cond_init(&hay_hueco,NULL);

    
    for(int i=0;i<10;i++){
        idsE[i]=i;
        pthread_create(&_entrar[i],NULL,enter,&idsE[i]);
        idsS[i]=i;
        pthread_create(&_irse[i],NULL,leave,&idsS[i]);
    }
    
    for(int i=0;i<10;i++){
        pthread_join(_entrar[i],NULL);
        pthread_join(_irse[i],NULL);
    }

    pthread_mutex_destroy(&m);
    pthread_cond_destroy(&hay_hueco);

    return 0;
}