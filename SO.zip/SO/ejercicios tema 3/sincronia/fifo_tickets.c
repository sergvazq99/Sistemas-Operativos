#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

long next_ticket_to_give = 0;
long next_ticket_to_serve = 0;

pthread_mutex_t m;
pthread_cond_t cond;


void enter_fifo(void) {
    pthread_mutex_lock(&m);
    long my = next_ticket_to_give++;

    while(my!=next_ticket_to_serve){
        pthread_cond_wait(&cond,&m);
    }

    printf("Entrando numero de ticket: %ld\n",my);

    pthread_mutex_unlock(&m);
}



void leave_fifo(void) {
    pthread_mutex_lock(&m);
    printf("Dejando numero ticket: %ld\n",next_ticket_to_serve);
    next_ticket_to_serve++;
    pthread_cond_broadcast(&cond);
    pthread_mutex_unlock(&m);
}

void*fifo(void){
    enter_fifo();
    sleep(1);
    leave_fifo();
    return NULL;
}

int main(void){
    pthread_t hilos[10];
    pthread_mutex_init(&m,NULL);
    pthread_cond_init(&cond,NULL);

    
    for(int i=0;i<10;i++){
        pthread_create(&hilos[i],NULL,fifo,NULL);
    }
    
    for(int i=0;i<10;i++){
        pthread_join(hilos[i],NULL);
    }

    pthread_mutex_destroy(&m);
    pthread_cond_destroy(&cond);
    return 0;
}