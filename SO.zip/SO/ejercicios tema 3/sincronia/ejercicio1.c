#include <pthread.h>

#include <stdio.h>



void *trabajador(void *arg) {
    int id=*(int*)arg;
    printf("Hola soy el hilo: %d\n",id);

    return NULL;

}



int main(void) {
    pthread_t h1;
    int id=1;

    pthread_create(&h1,NULL,trabajador,&id);

    pthread_join(h1,NULL);

    return 0;

}