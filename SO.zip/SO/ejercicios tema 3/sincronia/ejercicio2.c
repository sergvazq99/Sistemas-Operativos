#include <pthread.h>

#include <stdio.h>



int contador = 0;



void *sumador(void *arg) {
    for (int i = 0; i < 100000; i++) {
        contador++;
    }

    return NULL;
}



int main(void) {
    pthread_t a, b;

    pthread_create(&a,NULL,sumador,NULL);
    pthread_create(&b,NULL,sumador,NULL);

    pthread_join(a,NULL);
    pthread_join(b,NULL);

    printf("Resultado final: %d\n",contador);
    return 0;
}