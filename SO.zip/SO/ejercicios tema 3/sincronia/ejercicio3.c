#include <pthread.h>

#include <stdio.h>



int contador = 0;

pthread_mutex_t m;



void *sumador(void *arg) {
    for (int i = 0; i < 100000; i++) {
        pthread_mutex_lock(&m);
        contador++;
        pthread_mutex_unlock(&m);
    }
    return NULL;
}



int main(void) {
    pthread_t a, b;

    pthread_mutex_init(&m,NULL);

    pthread_create(&a,NULL,sumador,NULL);
    pthread_create(&b,NULL,sumador,NULL);

    pthread_join(a,NULL);
    pthread_join(b,NULL);

    printf("Resultado final: %d\n",contador);

    pthread_mutex_destroy(&m);
    return 0;
}